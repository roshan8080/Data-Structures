/** DPKnapsack.java
  * CSCI 3005
  * Programming Assignment 1
  * @author: Anamol Shrestha
  * Due Date: 03/13/2017
  * Implements a class DPKnapsack.java to generate solution to 0-1 Knapsack problem . The objective
    of the class is to solve the problem using dynamic programming. It will first store the various 
    items and its respective value and weight from a text file and then generate Knapsack table for
    the given knapsack capacity. It will then create the optimal solution for the knapsack. It also contain
    method to generate knapsack table and its optimal table for different maximum weight. Ih has method to
    give the respective weight, value and name of the items in the optimal solution for their respective weights. 
  * 
  */

import java.util.*;
import java.io.*;


public class DPKnapsack {
   
   /** Data fields representing 
       Two Arraylists to add the items from the text file and to keep optimal solution.
       Two dimensional arrays to store knapsack table and to determine if the item is present knapsack
       int and String to store the size of an knapsack and name of the text file respectively.
     */
   
   private ArrayList<Item> list = new ArrayList<Item>();
   private int size =0;
   private int[][] soin;
   private boolean[][] keep;
   private ArrayList<Item> optimalSolution = new ArrayList<Item>();
   private String name ="";
	   
	   
	 /**A constructor to accept the default capacity and the name of a data file as arguments. It 
       will create a new DPKnapack object. The instance variable storing the size of the knapsack
       is initialized with integer value passed as argument. It will scan the items present in the
       given text file and store in a arraylist. It will also call methods to generate knapsack table
       and its respective optimal solution. 
	 * @param capacity - Capacity of the Knapsack
	 * @param itemFile - Name of the text file that contains item.
	 */
   public DPKnapsack(int capacity, String itemFile){
            
      size = capacity;
      name = itemFile;
            
      File file = new File(name);
      try{
         Scanner scan = new Scanner(file);
           
         while(scan.hasNextLine()){
            String line = scan.nextLine();
            String[] temp = line.split(" ");
            String name= temp[0];
            int weight= Integer.parseInt(temp[1]);
            int value = Integer.parseInt(temp[2]);
            Item a = new Item(name, weight, value);
            list.add(a);     
         }
      }
      catch(FileNotFoundException ex){
         System.out.println("The file couldn't be open. Please try again");
      }
      knapsackSoin();
      getOptimal();  
   }
	   
	      
	   /**
	 * Method generates the knapsack table for the given problem.
      The method will use knapsack algorithm to create a knapsack table and
      store in a two dimensional array. It will also create two dimensional boolean
      array to determine whether the item is present in the knapsack or not.
	 */
	
   public void knapsackSoin(){
      int totalItem = list.size();
      soin = new int[totalItem+1][size+1];
      keep = new boolean[totalItem+1][size+1];
       
      for(int col =0; col <=size;col++){
         soin[0][col]=0;
      } 
                         
      for(int item=1; item<=totalItem;item++){
              
         for(int weight =0; weight<=size;weight++){
            if(list.get(item-1).getWeight()<=weight){
               int newNub = list.get(item-1).getValue()+soin[item-1][weight-list.get(item-1).getWeight()];
               int sameNub = soin[item-1][weight];
               if(newNub>sameNub){
                  soin[item][weight]= newNub;
                  keep[item][weight] = true;    
               }
               else{
                  soin[item][weight] = sameNub;
               }
                  
            }
                           
            else{
               soin[item][weight]= soin[item-1][weight];
            }
         }    
      }
        
   }
	  /** Method generates the optimal solution from the knapsack table.
         The method will use the boolean array to generate the optimal solution
         and store them in the arraylist. 
     */
	
	
   public void getOptimal(){
         
      int i = list.size();
      int j = size;   
      while(i>0 && j>0){
         if(keep[i][j]==true){
            optimalSolution.add(list.get(i-1));
            j= j-list.get(i-1).getWeight();
            i--;
         }
         else{
            i--;
         }
      }
         
   }

	 /** Method that return the items contained in the optimal solution. It will 
        display the items and its respective name, value and weights in a string.
	 * @return - A String that gives the items present in the optimal solution.
	 */
   public String solution(){
       
      System.out.println("\nThe optimal solution for the knapsack capacity " + size + " contains following items: \n");
      String solution= "Name\t\tWeight\tValue\n";
      for(Item a : optimalSolution){
         solution += a.toString();
      } 
      return solution;
   }
	 /**Method that return the total weight of the items contained in the optimal solution.
     It will give a numberic value of overall weight of the items in the optimal solution.
	 * @return - A numeric value of total weight of the items in the optimal solution.
	 */
   public int optimalWeight(){
              
      int optimalWeight=0;
         
      for(Item a: optimalSolution){
         optimalWeight += a.getWeight();
      }
      return optimalWeight;
   
   }
	   
	 /**Method that return the boolean value to determine whether a item is present in the optimal solution.
       It will give boolean value whether the given item passed as a argument is present in the optimal solution.
	 * @param item - Name of the item to be determined if it is present in the optimal solution. 
	 * @return - A boolean value the given item is present or not.
	 */
	
   public boolean contains(String item){
               
      for(Item a : optimalSolution){
         if(item.equals(a.getName())){
            return true;
         }
      }
      return false;
   
   }
	   
	 /** Method that returns the total number of the items present in the optimal solution.
        It will return the numberic value of items present in the solution. 
	 * @return - A number of items in the optimal solution.
	 */
   public int optimalNumber(){
            
      int a = optimalSolution.size();
      return a;
   }
	   
	      
	 /** Method that return the total weight of the items contained in the optimal solution for 
        given weight. It will create new DPKnapsack object for the given weight and give a numberic 
        value of overall weight of the items in the optimal solution. It does so by calling the optimalWeight()
        method. 
	 * @param maxWeight - Maximum weight for the knapsack
	 * @return - A numeric value of total weight of the items for the given weight in the optimal solution.
	 */
   public int optimalWeight(int maxWeight){
        
      DPKnapsack newSoin = new DPKnapsack(maxWeight, name);
      int newWeight = newSoin.optimalWeight();
      return newWeight;
         
   }
	   
	 /** Method that returns the total number of the items present in the optimal solution for the given weight.
        It will create new DPKnapsack object for the given weight and give a numberic value of total number
        of the items in the optimal solution. It does so by calling the optimalNumber() method.

	 * @param maxWeight - Maximum weight for the knapsack.
	 * @return - A number of items in the optimal solution for the given weight.
	 */
   public int optimalNumber(int maxWeight){
        
      DPKnapsack newSoin = new DPKnapsack(maxWeight, name);
      int newNumber = newSoin.optimalNumber();
      return newNumber;
   } 
	   
	 /**Method that return the boolean value to determine whether a item is present in the optimal solution for the
       given weight. It will give boolean value whether the given item passed as a argument is present in the optimal solution.
       
	 * @param item - Name of the item to be determined if it is present in the optimal solution. 
	 * @param maxWeight - Maximum weight for the knapsack.
	 * @return - A boolean value the given item is present or not.
	 */
   public boolean contains(String item, int maxWeight){
      DPKnapsack newSoin = new DPKnapsack(maxWeight, name);
      boolean newContain = newSoin.contains(item);
      return newContain;
   }
	   
	 /**Method that return the items contained in the optimal solution for the given weight. It will 
       display the items and its respective name, value and weights in a string.
       
	 * 
	 * @param maxWeight - Maximum weight for the knapsack.
	 * @return - A String that gives the items present in the optimal solution for the given weight.
	 */
   public String solution(int maxWeight){
        
      DPKnapsack newSoin = new DPKnapsack(maxWeight, name);
      String newSolution = newSoin.solution();    
      return newSolution;
   }

}
