/** Item.java
  * CSCI 3005
  * Programming Assignment 1
  * @author: Anamol Shrestha
  * Due Date: 03/13/2017
  * Support class of the DPKnapsack class that defines the properties of the items. 
  * 
  */

public class Item {
   
   /** Data fields representing thename, weight and value of the item.
    */

   String name="";
   int weight= 0;
   int value=0;
	  
	 /**Creates a new Item object and initializes the instance variables. The instance
       variables name, weight and value  is initialized with the value passed as argument.

	 * @param name - Name of the Item.
	 * @param weight - Weight of the Item.
	 * @param value - value of the Item.
	 */
   public Item(String name, int weight, int value){
      this.name = name;
      this.weight = weight;
      this.value= value;
   }

	 /** Method that returns the name of item.
	 * @return - Name of the item.
	 */
   public String getName(){
      return name;
   }

	 /** Method that returns the weight of the item.
	 * @return - Weight of the item.
	 */
   public int getWeight(){
      return weight;
   }
	 /** Methos that returns the value of the item.
	 * @return - value of the item.
	 */
   public int getValue(){
      return value;
   }
	 /**Method that returns the properties of the item in a properly formatted String. 
	  * @return - String that contains the properties of the item.
	  */
   public String toString(){
      String temp="";
      temp = String.format("%-10s\t%5d\t%5d\n", name, weight, value);
      return temp;
   
   }

}